# 03. Three GA4 Admin API Limitations

These came from actually building this framework against a live account through the API, not from
documentation. Read this before you build a single list through the API - all three will otherwise
surface as a confusing rejected filter partway through Wave 3 or later.

---

## Limitation 1: `lifetimeValue` does not work in audience filters through the API

LTV percentile (top 10%, top 25%, and so on) exists only as a suggested-audience UI template. Try
to build the same condition through the Admin API and you get a rejection on that field - there is
no equivalent filter parameter to switch to. The UI has this; the API does not.

**Workaround: frequency proxy.** Purchase count correlates with value well enough to make a better
bid decision than having no value signal at all, even though it is not the same thing as actual
value:
- Champions (top ~10% by value) → `purchase` event count > 2, at any point in time
- High value (top ~25% by value) → `purchase` event count > 1, at any point in time

If you need the real value figure rather than a proxy, build it in your CRM or email platform
(where you already have real RFM numbers) and bring it into Google Ads as a Customer Match list.
GA4 gives you breadth; CRM gives you precision. See `04_ads_activation.md` for that split in full.

---

## Limitation 2: count filters have no rolling window

`eventCount` filters only work with `atAnyPointInTime: true` - meaning "ever," not "in the last N
days." There is no rolling-window version of a count condition.

**Workaround: move the window onto membership duration instead.** "2 or more purchases in the last
540 days" becomes "2 or more purchases, ever" as the include condition, with membership duration
set to 540 days. The result is close to the intended condition but not identical: someone whose two
purchases happened three years ago will still qualify if they revisit the site today and refresh
their membership. In practice this rarely matters for a repeat-buyer list, but it is worth knowing
before you rely on it for something precision-sensitive.

---

## Limitation 3: "has not purchased in the last N days" cannot be built directly

This is the limitation that breaks half of every win-back and replenishment idea on first attempt.
A GA4 exclude condition is scoped to that same list's own membership window, so a
"temporarily exclude" clause only works cleanly when the include and exclude windows already match
(this is why it works for the INT pillar - cart/checkout/view windows and the purchase exclusion
window are the same length). It does not work for "purchased 45-120 days ago, nothing since,"
because that needs two different windows at once.

**Workaround: build it in Google Ads, not in GA4.** The target list is built as-is in GA4 (the
upper bound), and the lower bound - "hasn't bought recently" - is applied as an exclusion when the
audience is attached to a campaign:

```
target list  MINUS  active-customers list (on the matching short window)
```

This is why the helper list `LCY_ALL_ActiveCustomers_45d` exists, and why it gets cloned onto
several different windows (25d, 45d, 120d) rather than built once. Each replenishment or
win-back combination needs its own matching exclusion window. Full pairing table in
`04_ads_activation.md`.

---

## Filter schema notes (API route)

If you are building through the Admin API directly rather than having your LLM do it, the filter
structure and a few hard constraints to know before you start:

- **Schema shape:** filters nest as `andGroup → orGroup → leaf`. There is no flatter shortcut -
  even a single-condition audience is expressed inside this nesting.
- **Comparison operator:** only `GREATER_THAN` exists for count conditions. There is no
  `GREATER_THAN_OR_EQUAL`. To express "3 or more," write the condition as `eventCount > 2`, not
  `eventCount >= 3`. This trips people up on every "X+" condition in `01_audiences.md` - check each
  one against this before submitting it.
- **Description length:** audience descriptions are capped at roughly 150 characters through the
  API. Keep the description field short and functional (what the list is for), not a restatement
  of the full definition - that belongs in your own build log, not the GA4 field.
