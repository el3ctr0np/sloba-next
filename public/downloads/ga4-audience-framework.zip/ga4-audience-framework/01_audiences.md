# 01. The 25 Audiences

This file is a spec, not an article. Every row gives the full audience configuration - the include
condition, the exclude condition, the toggles and the membership duration - so an LLM (or you, by
hand) can turn it directly into a GA4 audience without inventing the logic.

Three things it deliberately does not give you, because they belong to your account or to a
version of the GA4 interface that will have moved by the time you read this:
the on-screen click path (your LLM or the GA4 UI supplies that), the audience description text
(write one line saying what the list is for - the Wave 1 check only asks that the field is filled),
and account-specific values: your `item_brand` values, the product token for the step-up line, the
category tokens for replenishment, and whether your site search event is named `view_search_results`
or `search`. Those are inputs you bring. Read `03_api_limits.md` before building any of
this through the API - three of the conditions below cannot be built literally as written and have
a documented workaround.

## Count and naming

25 list definitions = 24 target audiences across six pillars + 1 helper definition
(`LCY_ALL_ActiveCustomers_45d`) that exists only to be subtracted from other lists in Google Ads.
The helper is not a targeting audience on its own, and it is one definition rather than one object:
you clone it onto whichever windows your combinations need. A full build of this framework needs two
more copies of it - 25 days for the supplement cycle (Wave 5) and 120 days for the at-risk value tier
(Wave 3) - so the property ends up holding 27 audiences for 25 definitions. The 90-day active
customers list is not one of those clones; it is `LCY_ALL_ActiveCustomers_90d`, a first-class
lifecycle list. See the rows below and `04_ads_activation.md`.

Naming convention:

```
{PILLAR}_{SCOPE}_{Segment}_{Window}
```

| Pillar | Meaning |
|---|---|
| `LCY` | Lifecycle - customer life-cycle stage |
| `VAL` | Value / RFM - value tiers |
| `INT` | Intent - funnel abandoners |
| `BRD` | Brand affinity - by brand or product line |
| `RPL` | Replenishment - repurchase cycle |
| `PRD` | Predictive - Google ML |

`SCOPE` is `ALL` (whole account) or a brand/category tag (`BR1`, `BR2`, `MOI`, `SUP`, `SPF`).
`WINDOW` is the membership window or the target range (`90d`, `540d`, `45-120d`).

With 25 lists in one property, prefix search is the only realistic way to find the right one three
months from now. Keep the naming exact - it is doing organizational work, not decoration.

## Configuration format

Every row below follows: **Include** (the condition that adds a user) · **Exclude** (the condition
that removes a user, if any) · **Membership duration** (how long a user stays once qualified).
"At any point in time" is the GA4 toggle that makes a condition lifetime instead of tied to a
rolling window - it changes the meaning of the condition, not just its scope, so do not drop it
when it appears.

---

## Pillar: LCY - Lifecycle (6 lists)

### 1. `LCY_ALL_FirstTimeBuyers_180d`
- **Definition:** exactly one purchase ever, most recent within 180 days.
- **Include:** `purchase` event count = 1, at any point in time, AND `purchase` occurred within
  the last 180 days.
- **Exclude:** none.
- **Membership duration:** 180 days.
- **Purpose:** the second order is the KPI that decides whether an account is actually growing.
  This is the only list in the framework that targets it directly.

### 2. `LCY_ALL_RepeatBuyers_540d`
- **Definition:** 2 or more purchases ever.
- **Include:** `purchase` event count > 1, at any point in time.
- **Exclude:** none.
- **Membership duration:** 540 days.
- **Purpose:** the value core of the account. Used for bid boosts and as a Similar-audience seed.

### 3. `LCY_ALL_ActiveCustomers_90d`
- **Definition:** purchased at least once in the last 90 days.
- **Include:** `purchase`, at least once, within 90 days.
- **Exclude:** none.
- **Membership duration:** 90 days.
- **Purpose:** exclusion from acquisition campaigns, and the base list for cross-sell targeting.

### 4. `LCY_ALL_Purchasers_365d`
- **Definition:** purchased at any point in the last 365 days.
- **Include:** `purchase`, at least once, within 365 days.
- **Exclude:** none.
- **Membership duration:** 365 days.
- **Purpose:** raw material for win-back. In Google Ads: this list MINUS
  `LCY_ALL_ActiveCustomers_90d` = lapsed customers.

### 5. `LCY_ALL_EngagedNonBuyers_30d`
- **Definition:** 2 or more sessions in 30 days, never purchased.
- **Include:** `session_start` event count > 1. In the UI you can scope this to a 30-day window; through
  the API a count filter has to run with `atAnyPointInTime` (see `03_api_limits.md`, limit 2), so the
  30-day framing is carried by the membership duration instead.
- **Exclude:** `purchase`, at any point in time.
- **Membership duration:** 30 days.
- **Purpose:** prospecting seed for Demand Gen and lookalike-style logic.

### 6. `LCY_ALL_NewVisitors_7d`
- **Definition:** first visit within 7 days, no purchase.
- **Include:** `first_visit`.
- **Exclude:** `purchase`, at any point in time.
- **Membership duration:** 7 days.
- **Purpose:** soft remarketing while brand memory is fresh. The short membership is deliberate,
  not an oversight - this list should not still contain people from a month ago.

---

## Pillar: VAL - Value / RFM (4 lists)

### 7. `VAL_ALL_Champions_Top10_540d`
- **Definition:** top 10% of customers by value.
- **UI route:** suggested audience template using the LTV percentile field, set to top 10%.
- **API route:** `lifetimeValue` cannot be filtered through the API (see `03_api_limits.md`,
  limitation 1). Use the frequency proxy instead: `purchase` event count > 2, at any point in
  time.
- **Membership duration:** 540 days.
- **Purpose:** protection and Similar-audience seeding. Hard rule: this segment never sees a
  discount-led message.

### 8. `VAL_ALL_HighValue_Top25_540d`
- **Definition:** top 25% of customers by value.
- **UI route:** LTV percentile template, top 25%.
- **API route:** frequency proxy - `purchase` event count > 1, at any point in time.
- **Membership duration:** 540 days.
- **Purpose:** target ROAS boost, remarketing priority.

### 9. `VAL_ALL_AtRisk_HighValue_120d`
- **Definition:** high-value customer who has not purchased in 120 days.
- **Include:** same condition as #8 (frequency proxy or LTV template).
- **Exclude:** "has not purchased" is not buildable inside this list - it is resolved in Google Ads
  as this list MINUS `LCY_ALL_ActiveCustomers_120d` (a clone of the helper list on a 120-day
  window). See limitation 3 in `03_api_limits.md`.
- **Membership duration:** 120 days.
- **Purpose:** the most expensive loss in the account if it goes unaddressed. "Can't lose them"
  targeting.

### 10. `VAL_ALL_OneTimeLowValue_365d`
- **Definition:** exactly one purchase, in the bottom half of customers by value.
- **Include:** `purchase` event count = 1, at any point in time.
- **UI refinement:** intersect with LTV bottom 50% if using the UI template; on the API route, the
  frequency condition alone is the achievable version.
- **Exclude:** none.
- **Membership duration:** 365 days.
- **Purpose:** exclusion from expensive remarketing. Not every customer earns the same bid.

---

## Pillar: INT - Intent / funnel (4 lists)

### 11. `INT_ALL_CartAbandoners_14d`
- **Definition:** added to cart within 14 days, did not purchase.
- **Include:** `add_to_cart` within a 14-day window.
- **Exclude:** `purchase` within the same 14-day window (temporarily-scoped exclude - this works
  because the include and exclude windows match; see limitation 3).
- **Membership duration:** 14 days.
- **Purpose:** the hottest layer in the account. Highest bid ceiling.

### 12. `INT_ALL_CheckoutAbandoners_7d`
- **Definition:** started checkout within 7 days, did not purchase.
- **Include:** `begin_checkout` within a 7-day window.
- **Exclude:** `purchase` within the same 7-day window (temporarily-scoped).
- **Membership duration:** 7 days.
- **Purpose:** urgent layer. Runs alongside an abandoned-checkout email flow, not instead of one.

### 13. `INT_ALL_ProductViewers_NoATC_30d`
- **Definition:** viewed a product within 30 days, never added to cart.
- **Include:** `view_item` within a 30-day window.
- **Exclude:** `add_to_cart` within the same 30-day window (temporarily-scoped).
- **Membership duration:** 30 days.
- **Purpose:** middle layer - cheaper bid, larger volume than the two lists above.

### 14. `INT_ALL_SearchUsers_30d`
- **Definition:** used on-site search within 30 days.
- **Include:** `view_search_results` (or `search`, depending on how your implementation names the
  event) within a 30-day window.
- **Exclude:** none.
- **Membership duration:** 30 days.
- **Purpose:** the most overlooked intent signal available. Someone typing into your own search bar
  is telling you exactly what they want.

---

## Pillar: BRD - Brand affinity (5 lists, multi-brand accounts)

`BR1` / `BR2` stand in for your top two brands by revenue. If the account sells a single brand,
skip this pillar's brand framing and rebuild it on product categories instead (`SER` for serum,
`CLE` for cleanser, and so on) - the logic underneath does not change, only the scope tag.

Before building any list in this pillar: **confirm `item_brand` actually reaches GA4.** In many
accounts it is empty or inconsistent. If it is, fall back to a `page_location` URL pattern for the
brand slug, or to `item_category`. Check this before building, not after.

### 15. `BRD_BR1_Purchasers_365d`
- **Definition:** purchased the primary brand.
- **Include:** `purchase` where the item-scoped dimension `item_brand` = `BR1`.
- **Exclude:** none.
- **Membership duration:** 365 days.
- **Purpose:** core of the largest brand.

### 16. `BRD_BR1_StepUp_Purchasers_365d`
- **Definition:** purchased a more advanced line within that brand.
- **Include:** `purchase` where `item_name` contains the line's product token.
- **Exclude:** none.
- **Membership duration:** 365 days.
- **Purpose:** a customer entering a subscription-shaped buying pattern - the best candidate for
  growing order value.

### 17. `BRD_BR1_Browsers_NoBuy_60d`
- **Definition:** viewed BR1 products, has not purchased them.
- **Include:** `view_item` with `item_brand` = `BR1`, within 60 days.
- **Exclude:** `purchase` with `item_brand` = `BR1`, at any point in time.
- **Membership duration:** 60 days.
- **Purpose:** brand-specific remarketing - the message can reference the actual brand the user
  looked at.

### 18. `BRD_BR2_Purchasers_365d`
- **Definition:** purchased the second brand by revenue.
- **Include:** same structure as #15, with `item_brand` = `BR2`.
- **Exclude:** none.
- **Membership duration:** 365 days.
- **Purpose:** second brand core.

### 19. `BRD_BR2_Browsers_NoBuy_60d`
- **Definition:** viewed BR2 products, has not purchased them.
- **Include:** same structure as #17, with `item_brand` = `BR2`.
- **Exclude:** `purchase` with `item_brand` = `BR2`, at any point in time.
- **Membership duration:** 60 days.
- **Purpose:** remarketing for the second brand.

---

## Pillar: RPL - Replenishment (3 lists)

The part of this framework most accounts never build. Each list name carries a target window
(`45-120d`) that is not literally buildable inside GA4 as a single list - GA4 builds the upper
bound as a membership window of customers, and the lower bound is created by an exclusion in
Google Ads. See limitation 3 in `03_api_limits.md` before building these.

### 20. `RPL_MOI_Due_45-120d`
- **Definition (effective, after the Ads exclusion is applied):** purchased a moisturiser 45 to
  120 days ago, nothing since.
- **Include:** `purchase` where `item_category` (or `item_name`) contains the moisturiser token.
- **Membership duration:** 120 days.
- **Ads exclusion:** MINUS `LCY_ALL_ActiveCustomers_45d`.
- **Purpose:** a moisturiser lasts roughly 60-90 days of use; the ad should land as the jar is
  running out, not before.

### 21. `RPL_SUP_Due_25-75d`
- **Definition (effective):** purchased a supplement 25 to 75 days ago.
- **Include:** `purchase` where category = supplements.
- **Membership duration:** 75 days.
- **Ads exclusion:** MINUS `LCY_ALL_ActiveCustomers_25d` (a clone of the helper list on a 25-day
  window).
- **Purpose:** a 60-capsule bottle runs about two months.

### 22. `RPL_SPF_Due_45-120d`
- **Definition (effective):** purchased SPF 45 to 120 days ago.
- **Include:** `purchase` where category = SPF.
- **Membership duration:** 120 days.
- **Ads exclusion:** MINUS `LCY_ALL_ActiveCustomers_45d`.
- **Purpose:** usage cycle plus a seasonal factor on top of it.

**These three windows are a starting point, not a fact about your account.** 45-120d and 25-75d are
derived from how long the packs last (a moisturiser 60-90 days of use, a 60-capsule supplement about
two months), not measured from your catalogue. Before you commit to them, run the cycle-derivation
prompt in `05_prompts.md` against your own order data and adjust the numbers, and the list names
with them.

**Window logic:** take how long the pack actually lasts and start advertising at roughly 70-80% of
that cycle. A moisturiser lasting 60-90 days starts at 45. A supplement lasting ~60 days starts at
25-30. If you do not know the real cycle, derive it from your own order data - the average gap
between a customer's first and second purchase in the same category. See the cycle-derivation
prompt in `05_prompts.md`.

---

## Pillar: PRD - Predictive (2 lists, eligibility-gated)

These exist only if the GA4 property qualifies for predictive metrics. There is no API route for
either - both are built manually in the GA4 interface.

### 23. `PRD_ALL_LikelyPurchasers_7d`
- **Definition:** Google ML prediction of purchase within 7 days.
- **Configuration:** GA4 UI → Audiences → Suggested audiences → Predictive → "Likely 7-day
  purchasers". Not buildable through the API.
- **Membership duration:** 30 days.
- **Purpose:** fuel for target ROAS bidding.

### 24. `PRD_ALL_ChurnRisk_7d`
- **Definition:** ML prediction of churn.
- **Configuration:** same route, "Likely 7-day churning purchasers".
- **Membership duration:** 30 days.
- **Purpose:** an email list, not an ad list - churn risk is addressed with a message, not a bid.

**Eligibility:** predictive metrics require enough positive and negative examples in the property
(Google's own bar is on the order of 1,000 users who did, and 1,000 who did not, complete a
`purchase` within a 28-day window), and the model has to stay "eligible" over time. Small stores
simply will not qualify here. That is not a setup mistake - it is a volume floor.

---

## Helper list (1)

### 25. `LCY_ALL_ActiveCustomers_45d`
- **Definition:** purchased in the last 45 days.
- **Include:** `purchase`, at least once, within 45 days.
- **Exclude:** none.
- **Membership duration:** 45 days.
- **Purpose:** exclusion only. Not a targeting audience. Clone it onto other windows as other
  pillars need them: 25 days for the supplement replenishment exclusion, 90 days for the win-back
  exclusion, 120 days for the at-risk-high-value exclusion.
