# 04. Ads Activation

Lists existing in GA4 is not the same thing as lists doing anything in Google Ads. This file
covers what happens after `01_audiences.md` and `02_build_order.md` are done: delivery thresholds,
the target-minus-exclusion pattern, what to keep out of acquisition, and where GA4 stops being the
right source of truth.

## Delivery thresholds

Google will not deliver ads against a list below its minimum size, regardless of how correctly it
is configured:

| Channel | Minimum |
|---|---|
| Search (RLSA) | 1,000 active users in the last 30 days |
| Shopping | 1,000 active users in the last 30 days |
| Display | 100 active users |
| YouTube | 100 active users |
| Demand Gen | 100 active users |

Small lists live as Observation until they cross this line - zero effect on delivery, but you get
real numbers on your own account instead of borrowed benchmarks once they do. The common failure
mode here isn't a bad audience, it's building five lists, having none of them cross threshold, and
concluding that audiences "don't work" for the account. Check the number before drawing that
conclusion.

## Observation-first rule

Every list in this framework goes onto Search and Shopping campaigns as **Observation** first, not
straight into targeting or bidding. Observation has no effect on who sees the ad - it exists purely
to let the list accumulate performance data attached to it. After roughly two weeks in Observation,
you have enough of your own numbers to decide whether a list deserves an active role. Skipping this
step means making a targeting or bid decision on a list you have never actually observed.

## The target-minus-exclusion pattern

Several lists in this framework only mean what they're named once paired with an exclusion - this
follows directly from limitation 3 in `03_api_limits.md` (GA4 cannot build "hasn't purchased
recently" as a single condition). The pairing has to be applied at the campaign level in Ads:

| Goal | Target list | MINUS (exclusion) |
|---|---|---|
| Win back lapsed customers | `LCY_ALL_Purchasers_365d` | `LCY_ALL_ActiveCustomers_90d` |
| At-risk high value | `VAL_ALL_AtRisk_HighValue_120d` | `LCY_ALL_ActiveCustomers_120d` |
| Moisturiser replenishment | `RPL_MOI_Due_45-120d` | `LCY_ALL_ActiveCustomers_45d` |
| Supplement replenishment | `RPL_SUP_Due_25-75d` | `LCY_ALL_ActiveCustomers_25d` |
| SPF replenishment | `RPL_SPF_Due_45-120d` | `LCY_ALL_ActiveCustomers_45d` |
| Pure acquisition | (no target list) | `LCY_ALL_ActiveCustomers_90d` |
| Demand Gen prospecting | `LCY_ALL_EngagedNonBuyers_30d` | `LCY_ALL_Purchasers_365d` |

Each row without a matching exclusion clone from Wave 1/3/5 in `02_build_order.md` will just target
the wrong people - build the exclusion list before you attach the campaign, not after you notice
the numbers look off.

## What to exclude from acquisition

Acquisition campaigns exist to find people who are not already customers. At minimum:
`LCY_ALL_ActiveCustomers_90d` should sit as an exclusion on every acquisition-facing Search,
Shopping, and prospecting campaign. Once `VAL_ALL_OneTimeLowValue_365d` clears threshold, exclude
it from expensive remarketing specifically (not from acquisition) - a single low-value purchase
does not justify the same bid as a repeat or high-value customer.

## Activation order, once lists exist

1. All lists onto Search/Shopping as Observation. No delivery impact.
2. Exclusions turn on as soon as the underlying list clears threshold:
   `ActiveCustomers_90d` out of acquisition flows, `OneTimeLowValue` out of expensive remarketing.
3. Bid adjustments come only after a list has filled and only on lists that have real volume behind
   them. A bid adjustment on a list that has not cleared its delivery threshold is a decision made on noise.
4. GA4 is breadth, CRM is precision. The same customer segments, rebuilt in your email/CRM tool
   using real order data (order count, real spend, not a frequency proxy), give you the accurate
   RFM numbers GA4's API cannot produce directly (limitation 1 in `03_api_limits.md`). Import those
   as Customer Match lists when precision matters more than reach - a GA4 list is an approximation,
   a CRM list is a fact.

## GA4-breadth vs CRM-precision, in one line

Use GA4 lists to reach people based on behavior you can see immediately (browsing, cart, search).
Use CRM/Customer Match lists when the decision depends on an exact number (real lifetime value,
exact order count, exact days-since-purchase) that the GA4 Admin API cannot filter on directly.
Both belong in the same account; they are not competing approaches.
