# GA4 Audience Framework

## What this is

A working spec for 25 GA4 audience lists for an ecommerce account: 24 target audiences across
six pillars, plus one helper list used only for exclusions. Every list has an exact GA4
configuration (include condition, exclude condition, the "at any point in time" toggle where it
applies, and membership duration), not just a name and an idea.

This is not a document to read. It is a set of files built to be handed to an LLM (Claude,
ChatGPT, whatever you use) so it can either build the lists for you through the GA4 Admin API, or
walk you through building them by hand in the GA4 interface. Either way, you end up with lists
that exist in your property, not a plan for lists you meant to build.

The structure, the three API limitations documented in `03_api_limits.md`, and the workaround for
each came from building this against a live multi-brand skincare account. Nothing here is theory.

## What this is not

- Not a Google Ads setup guide. It gets your lists built and tells you the delivery thresholds and
  the target-minus-exclusion combinations, but campaign structure, bidding strategy, and budget are
  a separate conversation.
- Not a fix for broken tracking. If your events do not fire correctly, no audience configuration
  changes that.
- Not a guarantee of a result. No file in this package promises a CPA or ROAS number. The only
  hard figures used anywhere are Google's own platform thresholds and time windows.

## What you need before you start

- A GA4 property with ecommerce events actually flowing: `view_item`, `add_to_cart`,
  `begin_checkout`, `purchase`. Not configured, not "should be working" - flowing, today, with
  values on `purchase`.
- Either GA4 Admin API access (a Google Cloud project with the Analytics Admin API enabled and
  edit rights on the property) or just a GA4 login with edit rights. You do not need both. The API
  route is faster once you have 25 lists to build; the UI route needs no setup at all.
- A Google Ads account linked to the GA4 property, if the end goal is running these as audiences
  in Ads. You can build all 25 lists without this link, but nothing reaches Ads until it exists.

If you are not sure whether your events are flowing: open GA4 → Realtime, make a test purchase on
your own site, and watch for `purchase` to appear with a value attached. If it does not appear,
stop and fix that first. See the honest warning at the bottom of this file.

## How to run it

Drop the whole folder into a Claude or ChatGPT conversation (all six files) and work through them
in order:

1. `01_audiences.md` - the 25 lists, what each one is, exact GA4 configuration for each.
2. `02_build_order.md` - the six waves to build them in, with a check after each wave before you
   move to the next.
3. `03_api_limits.md` - the three things the GA4 Admin API will not let you do, and the exact
   workaround for each. Read this before you start building through the API, not after you hit
   the first error.
4. `04_ads_activation.md` - once lists exist, how they actually get used in Google Ads: delivery
   thresholds, the target-minus-exclusion pattern, what to exclude from acquisition campaigns.
5. `05_prompts.md` - the actual prompts. Copy one into your LLM conversation and it does the
   building, walking, verifying, or cycle-derivation work described in the earlier files.

You do not have to read this framework end to end before doing anything. The fastest path is:
read this README, skim `01_audiences.md` once to see the shape of it, then paste the API-route or
UI-route prompt from `05_prompts.md` into your LLM and let it drive from there, checking back
against `02_build_order.md` after each wave.

## Quick start (one screen)

1. Confirm `purchase`, `add_to_cart`, `begin_checkout`, `view_item` are live in GA4 Realtime.
2. Open `05_prompts.md`, pick the API prompt if you have Admin API access, otherwise the UI
   prompt.
3. Paste it into your LLM. It will ask for your GA4 property ID (API route) or start walking you
   through the interface (UI route).
4. Build in the wave order from `02_build_order.md`. Stop and check after each wave.
5. Wait. Lists fill from the moment you create them, with roughly 30 days of backfill for users who
   already qualify. There is no more backfill than that. A list built today is usable in 2 to 4
   weeks, not tomorrow.
6. Once lists clear the delivery thresholds in `04_ads_activation.md`, move them from Observation
   into real targeting and exclusion in Ads.

## What to expect, and when

- Day 0: lists exist, membership is empty or near-empty except for the ~30-day backfill.
- Week 1-2: lists are filling. Too early to read size as a verdict on whether the audience "works."
- Week 2-4: lists are usable. This is when you check sizes against the Search/Shopping (1,000
  active users in 30 days) and Display/YouTube/Demand Gen (100 active users) thresholds, and start
  moving qualifying lists from Observation into real targeting or exclusion.
- Beyond 4 weeks: if a list still has not cleared its threshold, the account may simply not have
  the volume for that segment. That is a finding, not a failure of the build.

## If your tracking is not there yet

If `add_to_cart` does not reach GA4, stop here. Audiences do not fix tracking. Every list in this
framework is downstream of events that already have to be firing correctly. Building 25 audiences
on top of broken or partial event tracking produces 25 lists that quietly lie about who is in them.
Fix the event first, verify it in Realtime, then come back to `01_audiences.md`.

---

Slobodan Jelisavac, slobodan-jelisavac.com
