# 05. Prompts

Four ready-to-paste prompts. Each one assumes the LLM you paste it into also has the other five
files in this folder in context (drop the whole folder in, not just this file) - the prompts refer
back to `01_audiences.md`, `02_build_order.md`, and `03_api_limits.md` by name and expect the model
to actually read them, not guess at their contents.

---

## (a) API route - build the lists through the GA4 Admin API

**Use this when:** you have GA4 Admin API access (a Google Cloud project with the Analytics Admin
API enabled, and edit rights on the property) and want the lists built programmatically instead of
by hand. Have your GA4 property ID ready, and be ready to authenticate the API session however your
LLM environment requires (service account, OAuth, or an already-configured MCP/tool connection).

```
You are building the GA4 audience framework for my ecommerce property through the GA4 Admin API -
23 of the 25 definitions are API-buildable, the 2 predictive lists are not (see step 8),
using the spec in 01_audiences.md, the build sequence in 02_build_order.md, and the limitations
in 03_api_limits.md - all in this folder.

Before you build anything:
0. Walk me through the Wave 0 precondition check in 02_build_order.md first and get an explicit
   yes on each item. If purchase is not arriving in GA4 Realtime with a value, stop there and tell
   me to fix tracking. Do not build a single audience on top of a failed Wave 0.
1. Ask me for my GA4 property ID. Do not proceed without it.
2. Confirm you can authenticate against the GA4 Admin API in this environment. If you cannot,
   stop and tell me what you need.

Then:
3. Build the audiences in the exact wave order given in 02_build_order.md - Wave 1 (helper and
   lifecycle), then stop and report the Wave 1 check items before continuing. Do not skip ahead
   to a later wave until I confirm the current wave's check has passed.
4. For every condition in 01_audiences.md that runs into one of the three limitations in
   03_api_limits.md (LTV percentile, a rolling-window count, or a "hasn't purchased recently"
   exclusion), use the documented workaround from that file exactly as written. Do not invent a
   different workaround.
5. Respect the filter schema rules in 03_api_limits.md: andGroup -> orGroup -> leaf nesting,
   GREATER_THAN only (write "3+" as > 2), and keep descriptions under roughly 150 characters.
6. After each audience is created, report back its resource name and the wave it belongs to.
7. If the API rejects a filter for any reason, stop immediately, show me the exact error, and do
   not attempt a workaround I have not approved - even if you think you know the fix.
8. At the end of each wave, stop and give me the wave's check-list from 02_build_order.md so I can
   confirm before you continue.

Skip PRD_ALL_LikelyPurchasers_7d and PRD_ALL_ChurnRisk_7d - the API cannot build these, tell me to
do them manually in the GA4 UI when we reach Wave 6.
```

---

## (b) UI route - walk me through building it by hand

**Use this when:** you do not have or do not want to set up API access, and would rather be walked
through the GA4 interface directly, one list at a time. Have GA4 open in a browser tab before you
start.

```
Walk me through building the 25 GA4 audiences from 01_audiences.md by hand in the GA4 interface,
in the wave order from 02_build_order.md. I do not have Admin API access for this - UI only.

Rules for how you walk me through this:
0. Start with the Wave 0 precondition check from 02_build_order.md and wait for me to confirm every
   item before you give me a single audience. If purchase is not showing in Realtime with a value,
   stop and tell me to fix tracking first.
1. One audience at a time. Give me the exact click path (Admin > Audiences > New audience, which
   condition builder options to select, what to type into each field) for a single list, then
   stop and wait for me to confirm I've built it before giving me the next one.
2. Use the exact Include/Exclude/Membership duration values from 01_audiences.md for every list -
   do not paraphrase or approximate a condition.
3. For the value-tier lists, follow 01_audiences.md exactly rather than assuming a template exists.
   Champions and HighValue can use the LTV percentile suggested-audience template in the UI, since
   that field only works in the UI route (see 03_api_limits.md, limitation 1). AtRisk uses the same
   definition as HighValue with a 120-day membership, and OneTimeLowValue is a purchase count of
   exactly 1 that you narrow by value afterwards - there is no suggested template for either, so
   build them as custom audiences and do not invent one.
4. After each wave finishes, stop and walk me through that wave's "CHECK BEFORE YOU CONTINUE"
   block from 02_build_order.md before starting the next wave. If a check fails - especially the
   Wave 2 stop gate - tell me clearly to stop and go fix tracking rather than continuing.
5. For Wave 4 (brand lists), before giving me any building steps, walk me through checking
   item_brand in an Explore report first, and tell me what to do instead if it's empty or
   inconsistent.
6. For Wave 6 (predictive), check with me whether the predictive templates are showing as eligible
   in my GA4 UI before giving me any steps - if not eligible, tell me to skip the wave.
```

---

## (c) Verification prompt - check what actually got built

**Use this when:** some time has passed since building (a session ended, someone else did the
build, or you just want a second check) and you need to know what actually exists in the property
versus what the spec calls for, without re-reading the whole thing yourself.

```
Check what has actually been built in my GA4 property against the full spec in 01_audiences.md.

For each of the 25 lists:
1. Confirm whether it exists in GA4 Audiences at all.
2. If it exists, compare its actual Include condition, Exclude condition, and Membership duration
   against what 01_audiences.md specifies - flag any mismatch, however small (a membership
   duration off by even a few days counts).
3. If it does not exist, say so plainly - do not assume it's fine to skip.

Then give me a single list at the end, grouped as:
- Correctly built and matching spec
- Built but misconfigured (say exactly what's wrong for each)
- Missing entirely

Cross-check the wave dependencies from 02_build_order.md too: if a later-wave list is built but an
earlier-wave prerequisite it depends on (like an Ads exclusion clone of the helper list) is
missing, flag that specifically, not just as "list exists."
```

---

## (d) Cycle-derivation prompt - find the real replenishment window

**Use this when:** you're about to build the RPL pillar (Wave 5) and do not want to guess the
45-120 day or 25-75 day windows from `01_audiences.md` - those are stated as a starting point, not
a fact about your specific account. Have access to your own GA4 or order-level data before running
this.

```
I need the real repurchase cycle for my product categories, not the placeholder windows in
01_audiences.md (45-120d for moisturiser/SPF, 25-75d for supplements) - those are derived from how
long a pack lasts, not from my data.

Using my own GA4 data (or order export if I give you one), work out, per category:
1. The average number of days between a customer's first and second purchase in that same
   category - this is the real signal, not a guess about how long a product "should" last.
2. The distribution around that average, not just the mean - if it's wide, tell me so rather than
   collapsing it into a single number.
3. A recommended replenishment window, using the same logic as 01_audiences.md: start advertising
   at roughly 70-80% of the real cycle length, so the ad lands before the product actually runs
   out rather than after.

Do not present a result if I have not given you the data to calculate it from - ask me for the
export or the GA4 access you need first, rather than estimating from general ecommerce assumptions.
Once you have real numbers, tell me exactly how the RPL list names and windows in 01_audiences.md
should change to reflect them (e.g. RPL_MOI_Due_45-120d might become RPL_MOI_Due_50-100d based on
actual data) - I'll rebuild those specific lists with the corrected windows in Wave 5.
```
