# 02. Build Order

Six waves, in this order. Do not build value, brand, or replenishment lists before the wave ahead
of them has passed its check. Each wave depends on something the previous one verified.

## Wave 0 - Precondition (before any list exists)

Ecommerce events have to be live: `view_item`, `add_to_cart`, `begin_checkout`, `purchase`. The GA4
property has to be linked to the Google Ads account. Turn on Google signals if Display reach
matters to you.

**CHECK BEFORE YOU CONTINUE**
- Open GA4 → Realtime, run a real test purchase on the site, and confirm `purchase` appears with a
  value attached.
- If it does not appear: stop. Do not build a single audience. Fix the event, verify it in
  Realtime, then come back here. Every list downstream of this depends on these four events firing
  correctly - a framework built on top of broken tracking produces lists that quietly lie about who
  is in them.

- [ ] `view_item` confirmed in Realtime
- [ ] `add_to_cart` confirmed in Realtime
- [ ] `begin_checkout` confirmed in Realtime
- [ ] `purchase` confirmed in Realtime, with a value
- [ ] GA4 property linked to the Google Ads account
- [ ] Google signals enabled (only if Display reach is a goal)

---

## Wave 1 - Helper and lifecycle lists

Build in this order: #3 `LCY_ALL_ActiveCustomers_90d`, #4 `LCY_ALL_Purchasers_365d`, #25
`LCY_ALL_ActiveCustomers_45d`, then #1 `LCY_ALL_FirstTimeBuyers_180d`, #2
`LCY_ALL_RepeatBuyers_540d`, #5 `LCY_ALL_EngagedNonBuyers_30d`, #6 `LCY_ALL_NewVisitors_7d`. Full
configuration for each is in `01_audiences.md`.

**CHECK BEFORE YOU CONTINUE**
- Every list in this wave exists in GA4 → Admin → Audiences.
- Each one's membership duration matches the spec exactly (this is the field people get wrong
  under time pressure - double check it, not just the include condition).
- Each one has a description filled in (keep it under ~150 characters if you built it through the
  API - see `03_api_limits.md`).
- If any of this is off, fix it now. A wrong membership duration on a lifecycle list quietly
  breaks every Ads exclusion built on top of it later.

- [ ] `LCY_ALL_ActiveCustomers_90d` built, membership 90d
- [ ] `LCY_ALL_Purchasers_365d` built, membership 365d
- [ ] `LCY_ALL_ActiveCustomers_45d` built, membership 45d
- [ ] Helper clones built for every exclusion window you already know you need: 25d (supplements,
      Wave 5) and 120d (at-risk value tier, Wave 3). Building all of them now is cheaper than
      remembering to come back - they are the same list on a different membership duration.
- [ ] `LCY_ALL_FirstTimeBuyers_180d` built, membership 180d
- [ ] `LCY_ALL_RepeatBuyers_540d` built, membership 540d
- [ ] `LCY_ALL_EngagedNonBuyers_30d` built, membership 30d
- [ ] `LCY_ALL_NewVisitors_7d` built, membership 7d
- [ ] All descriptions filled in

---

## Wave 2 - Intent lists

Build #11 `INT_ALL_CartAbandoners_14d`, #12 `INT_ALL_CheckoutAbandoners_7d`, #13
`INT_ALL_ProductViewers_NoATC_30d`, #14 `INT_ALL_SearchUsers_30d`.

**CHECK BEFORE YOU CONTINUE - THIS IS THE STOP GATE**
- Wait 48 hours after creation, then check `INT_ALL_CartAbandoners_14d` for members.
- If it has members: the wave worked, `add_to_cart` is reaching GA4 correctly, and you continue to
  Wave 3.
- If it has zero members after 48 hours: `add_to_cart` is not reaching GA4, or not reaching it in a
  form the audience condition can read. **Stop here.** Do not build Wave 3 through Wave 6.
  Audiences are not a tracking fix - go back to Wave 0, re-verify the event in Realtime and in
  GTM/gtag if you use it, and do not resume building until it is confirmed live.

- [ ] `INT_ALL_CartAbandoners_14d` built
- [ ] `INT_ALL_CheckoutAbandoners_7d` built
- [ ] `INT_ALL_ProductViewers_NoATC_30d` built
- [ ] `INT_ALL_SearchUsers_30d` built
- [ ] 48-hour check done, `CartAbandoners` has members
- [ ] If zero members: stopped, tracking issue logged, not proceeding until fixed

---

## Wave 3 - Value lists

Build #7 `VAL_ALL_Champions_Top10_540d`, #8 `VAL_ALL_HighValue_Top25_540d`, #9
`VAL_ALL_AtRisk_HighValue_120d`, #10 `VAL_ALL_OneTimeLowValue_365d`. Use the UI's LTV percentile
template if you have it; use the frequency proxy from `03_api_limits.md` if building through the
API.

**CHECK BEFORE YOU CONTINUE**
- Decide, and document, which route you used (LTV template vs. frequency proxy) - the two produce
  different membership, and six months from now you need to know which one you're looking at.
- Confirm `VAL_ALL_AtRisk_HighValue_120d` is paired in your notes with its Ads exclusion
  (`LCY_ALL_ActiveCustomers_120d` - clone the helper list onto a 120-day window if you have not
  already).

- [ ] `VAL_ALL_Champions_Top10_540d` built, route documented (UI/API)
- [ ] `VAL_ALL_HighValue_Top25_540d` built, route documented
- [ ] `VAL_ALL_AtRisk_HighValue_120d` built, paired exclusion list noted
- [ ] `VAL_ALL_OneTimeLowValue_365d` built

---

## Wave 4 - Brand lists

Before building anything in this wave: confirm `item_brand` actually reaches GA4 and is
consistent. Open an Explore report broken down by `item_brand` for the last 30 days.

**CHECK BEFORE YOU CONTINUE (this check happens BEFORE building, not after)**
- Do values exist for `item_brand`? Are they consistent (same brand always spelled/tagged the same
  way)?
- If yes: build #15-19 as specified in `01_audiences.md`.
- If no or inconsistent: do not build on `item_brand`. Fall back to a `page_location` URL pattern
  for the brand slug, or to `item_category`, and rebuild the five list conditions on that field
  instead. Note in your build log which fallback you used.

- [ ] `item_brand` checked in Explore for 30 days
- [ ] Fallback decision made and documented, if needed
- [ ] `BRD_BR1_Purchasers_365d` built
- [ ] `BRD_BR1_StepUp_Purchasers_365d` built
- [ ] `BRD_BR1_Browsers_NoBuy_60d` built
- [ ] `BRD_BR2_Purchasers_365d` built
- [ ] `BRD_BR2_Browsers_NoBuy_60d` built

---

## Wave 5 - Replenishment lists

Before building: confirm the category tokens used in the GA4 configuration (`item_category` /
`item_name`) match the tokens actually used in your product feed. A mismatch here is silent - the
list will build and simply stay small or empty.

**CHECK BEFORE YOU CONTINUE**
- Do feed categories and GA4 item data use the same token for moisturiser / supplements / SPF?
- Have you cloned the helper list onto the windows each replenishment list needs (`45d` for
  moisturiser and SPF, `25d` for supplements)?

- [ ] Category tokens checked against feed
- [ ] `LCY_ALL_ActiveCustomers_45d` confirmed available for exclusion (built in Wave 1)
- [ ] `LCY_ALL_ActiveCustomers_25d` cloned and built
- [ ] `RPL_MOI_Due_45-120d` built
- [ ] `RPL_SUP_Due_25-75d` built
- [ ] `RPL_SPF_Due_45-120d` built

---

## Wave 6 - Predictive lists

Manual, UI-only, and gated on model eligibility. Check GA4 → Audiences → Suggested → Predictive
first - if the templates are greyed out or absent, the property does not currently qualify.

**CHECK BEFORE YOU CONTINUE**
- Is the predictive model shown as "eligible" for this property? If not, skip this wave entirely -
  it is not a setup error, it is a volume floor the property has not crossed yet. Revisit in a
  future traffic period rather than forcing it.

- [ ] Model eligibility checked
- [ ] `PRD_ALL_LikelyPurchasers_7d` built (if eligible)
- [ ] `PRD_ALL_ChurnRisk_7d` built (if eligible)

---

## After two weeks - the wave that isn't a wave

- [ ] Re-open every list built and record current member count.
- [ ] Mark which lists have crossed a delivery threshold (1,000 active users in 30 days for
  Search/Shopping; 100 for Display/YouTube/Demand Gen - full detail in `04_ads_activation.md`).
- [ ] Move qualifying lists from Observation into active targeting or exclusion.
- [ ] Lists still below threshold stay in Observation. That is not a failed build - some segments
  in some accounts never reach volume, and that is a finding about the account, not the framework.

## Stop rule

If Wave 2 does not produce members in `CartAbandoners` within 48 hours, everything past that point
is wasted effort. Audiences do not repair tracking. Fix the event, re-verify, and only then resume
at Wave 2.
